package com.example.phoneai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class Agent(private val apiKey: String, private val log: (String) -> Unit) {
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
    private val history = JSONArray()

    private val system = "You are the user's personal assistant living on their Android phone. " +
        "Talk warmly and naturally, like a person. To act on the phone, use the tools: always " +
        "read_screen first, then tap/type/swipe, and re-read to verify. Ask the user before " +
        "anything irreversible (payments, deleting, sending money, posting). Never enter passwords."

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put("input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

    private fun num(d: String) = JSONObject().put("type", "number").put("description", d)
    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)

    private val tools = JSONArray().apply {
        put(tool("read_screen", "Return visible text and tappable elements with [x,y] centers."))
        put(tool("tap", "Tap screen coordinates.", JSONObject().put("x", num("x")).put("y", num("y")), listOf("x", "y")))
        put(tool("swipe", "Swipe between coordinates.", JSONObject().put("x1", num("")).put("y1", num("")).put("x2", num("")).put("y2", num("")), listOf("x1", "y1", "x2", "y2")))
        put(tool("type_text", "Type into the focused input field.", JSONObject().put("text", str("text")), listOf("text")))
        put(tool("open_app", "Open an app by its name.", JSONObject().put("name", str("app name")), listOf("name")))
        put(tool("press", "Press back, home, recents, or notifications.", JSONObject().put("key", str("back|home|recents|notifications")), listOf("key")))
        put(tool("wait", "Wait a number of seconds.", JSONObject().put("seconds", num("seconds")), listOf("seconds")))
    }

    private fun run(name: String, a: JSONObject): String {
        val s = PhoneControlService.instance ?: return "Accessibility service is not enabled."
        return when (name) {
            "read_screen" -> s.readScreen()
            "tap" -> s.tap(a.getDouble("x").toFloat(), a.getDouble("y").toFloat()).toString()
            "swipe" -> s.swipe(a.getDouble("x1").toFloat(), a.getDouble("y1").toFloat(), a.getDouble("x2").toFloat(), a.getDouble("y2").toFloat()).toString()
            "type_text" -> s.typeText(a.getString("text")).toString()
            "open_app" -> if (s.openApp(a.getString("name"))) "opened" else "app not found"
            "press" -> s.press(a.getString("key")).toString()
            "wait" -> { Thread.sleep((a.getDouble("seconds") * 1000).toLong()); "done" }
            else -> "unknown tool"
        }
    }

    /** Call from a background thread. */
    fun chat(userText: String) {
        history.put(JSONObject().put("role", "user").put("content", userText))
        repeat(25) {
            val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 2000)
                .put("system", system).put("tools", tools).put("messages", history)
            val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            val resp = JSONObject(http.newCall(req).execute().body!!.string())
            if (resp.has("error")) { log("Error: " + resp.getJSONObject("error").optString("message")); return }
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") == "text") log(b.getString("text"))
                if (b.getString("type") == "tool_use") {
                    log("▶ " + b.getString("name"))
                    val out = try { run(b.getString("name"), b.getJSONObject("input")) } catch (e: Exception) { "error: ${e.message}" }
                    results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
                }
            }
            if (results.length() == 0) return
            history.put(JSONObject().put("role", "user").put("content", results))
        }
    }
}
