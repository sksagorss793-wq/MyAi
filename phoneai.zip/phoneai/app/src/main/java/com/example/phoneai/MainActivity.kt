package com.example.phoneai

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private var agent: Agent? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val key = EditText(this).apply { hint = "Claude API key"; setText(getPreferences(0).getString("k", "")) }
        val enable = Button(this).apply {
            text = "1) Enable Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val out = TextView(this)
        val input = EditText(this).apply { hint = "কী করতে হবে বলুন…" }
        val send = Button(this).apply { text = "2) Send" }
        val scroll = ScrollView(this).apply { addView(out) }
        send.setOnClickListener {
            val k = key.text.toString().trim()
            getPreferences(0).edit().putString("k", k).apply()
            if (agent == null) agent = Agent(k) { m -> runOnUiThread { out.append("\n$m\n") } }
            val text = input.text.toString(); input.setText("")
            out.append("\nআপনি: $text\n")
            thread { agent!!.chat(text) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32)
            listOf(key, enable, input, send, scroll).forEach { addView(it) }
        })
    }
}
