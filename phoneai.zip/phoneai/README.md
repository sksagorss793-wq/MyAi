# PhoneAI (Android)

1. Android Studio -> New Project -> "Empty Views Activity" (Kotlin), package: com.example.phoneai
2. এই ফোল্ডারের ফাইলগুলো প্রজেক্টের একই পাথে বসান (AndroidManifest.xml, res/xml/accessibility_config.xml, চারটি .kt ফাইল)
3. build.gradle.kts.snippet-এর dependencies যোগ করুন
4. ফোনে রান করুন -> "Enable Accessibility" চেপে PhoneAI সার্ভিস চালু করুন
5. console.anthropic.com থেকে API key নিয়ে অ্যাপে বসান, তারপর নির্দেশ দিন
