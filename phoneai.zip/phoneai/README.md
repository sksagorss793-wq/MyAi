GitHub Actions এই zip আনজিপ করে APK বানায়। Actions ট্যাব -> Build APK -> Artifacts থেকে PhoneAI-apk নামান।
